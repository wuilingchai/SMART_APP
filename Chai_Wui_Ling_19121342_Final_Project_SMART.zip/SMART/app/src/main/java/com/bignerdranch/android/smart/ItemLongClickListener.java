package com.bignerdranch.android.smart;

import android.view.View;

interface ItemLongClickListener {
    void onItemLongClick(View v, int position);
}
